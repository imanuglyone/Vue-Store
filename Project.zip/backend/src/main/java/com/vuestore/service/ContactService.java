package com.vuestore.service;

import com.vuestore.dto.support.ContactRequest;
import com.vuestore.entity.ContactMessage;
import com.vuestore.repository.ContactMessageRepository;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;

@Service
public class ContactService {
  private final ContactMessageRepository contactMessageRepository;

  public ContactService(ContactMessageRepository contactMessageRepository) {
    this.contactMessageRepository = contactMessageRepository;
  }

  public void save(ContactRequest request) {
    ContactMessage message = new ContactMessage();
    message.setName(request.name());
    message.setEmail(request.email());
    message.setMessage(request.message());
    message.setCreatedAt(LocalDateTime.now());
    contactMessageRepository.save(message);
  }
}
