package com.vuestore.service;

import com.vuestore.dto.order.OrderItemResponse;
import com.vuestore.dto.order.OrderResponse;
import com.vuestore.entity.CartItem;
import com.vuestore.entity.Order;
import com.vuestore.entity.OrderItem;
import com.vuestore.entity.OrderStatus;
import com.vuestore.entity.User;
import com.vuestore.repository.CartItemRepository;
import com.vuestore.repository.OrderRepository;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {
  private final OrderRepository orderRepository;
  private final CartItemRepository cartItemRepository;

  public OrderService(OrderRepository orderRepository, CartItemRepository cartItemRepository) {
    this.orderRepository = orderRepository;
    this.cartItemRepository = cartItemRepository;
  }

  @Transactional
  public OrderResponse createOrder(User user) {
    List<CartItem> items = cartItemRepository.findByUser(user);
    if (items.isEmpty()) {
      throw new IllegalArgumentException("Cart is empty");
    }

    Order order = new Order();
    order.setUser(user);
    order.setStatus(OrderStatus.CREATED);
    order.setCreatedAt(LocalDateTime.now());

    BigDecimal total = BigDecimal.ZERO;
    for (CartItem item : items) {
      OrderItem orderItem = new OrderItem();
      orderItem.setOrder(order);
      orderItem.setProductName(item.getProduct().getName());
      orderItem.setProductPrice(item.getProduct().getPrice());
      orderItem.setQuantity(item.getQuantity());
      orderItem.setLineTotal(item.getProduct().getPrice()
        .multiply(BigDecimal.valueOf(item.getQuantity())));
      order.getItems().add(orderItem);
      total = total.add(orderItem.getLineTotal());
    }

    order.setTotalAmount(total);

    Order saved = orderRepository.save(order);
    cartItemRepository.deleteByUser(user);
    return toResponse(saved);
  }

  @Transactional(readOnly = true)
  public List<OrderResponse> getOrders(User user) {
    return orderRepository.findByUserOrderByCreatedAtDesc(user).stream()
      .map(this::toResponse)
      .toList();
  }

  @Transactional(readOnly = true)
  public OrderResponse getOrderById(User user, Long orderId) {
    Order order = orderRepository.findById(orderId)
      .orElseThrow(() -> new IllegalArgumentException("Order not found"));

    if (!order.getUser().getId().equals(user.getId())) {
      throw new IllegalArgumentException("Order not found");
    }

    return toResponse(order);
  }

  private OrderResponse toResponse(Order order) {
    List<OrderItemResponse> itemResponses = order.getItems().stream()
      .map(item -> new OrderItemResponse(
        item.getProductName(),
        item.getProductPrice(),
        item.getQuantity(),
        item.getLineTotal()
      ))
      .toList();

    return new OrderResponse(
      order.getId(),
      order.getStatus().name(),
      order.getTotalAmount(),
      order.getCreatedAt(),
      itemResponses
    );
  }
}
