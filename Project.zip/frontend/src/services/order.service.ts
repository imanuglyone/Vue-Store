import api from './api.service'
import type { Order } from '@/types'

export const orderService = {
  async createOrder(): Promise<Order> {
    const response = await api.post('/orders')
    return response.data
  },

  async getOrders(): Promise<Order[]> {
    const response = await api.get('/orders')
    return response.data
  },

  async getOrder(id: number): Promise<Order> {
    const response = await api.get(`/orders/${id}`)
    return response.data
  }
}
